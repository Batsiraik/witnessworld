<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/guard.php';

$pageTitle = 'App users';
$activeNav = 'users';

$pdo = witnessworld_pdo();

$filter = (string) ($_GET['status'] ?? 'all');
$allowed = [
    'all',
    'pending_otp',
    'pending_verification',
    'verified',
    'declined',
];
if (!in_array($filter, $allowed, true)) {
    $filter = 'all';
}

$search = trim((string) ($_GET['q'] ?? ''));
$perPage = 50;
$page = max(1, (int) ($_GET['page'] ?? 1));

$where = [];
$params = [];
if ($filter !== 'all') {
    $where[] = 'status = ?';
    $params[] = $filter;
}
if ($search !== '') {
    $where[] = '(first_name LIKE ? OR last_name LIKE ? OR CONCAT(first_name, " ", last_name) LIKE ? OR email LIKE ? OR username LIKE ? OR phone LIKE ?)';
    $term = '%' . $search . '%';
    array_push($params, $term, $term, $term, $term, $term, $term);
}
$whereSql = $where !== [] ? (' WHERE ' . implode(' AND ', $where)) : '';

$countSt = $pdo->prepare('SELECT COUNT(*) FROM users' . $whereSql);
$countSt->execute($params);
$totalRows = (int) $countSt->fetchColumn();
$totalPages = max(1, (int) ceil($totalRows / $perPage));
if ($page > $totalPages) {
    $page = $totalPages;
}
$offset = ($page - 1) * $perPage;

$sql = 'SELECT id, email, username, first_name, last_name, phone, status, created_at FROM users'
    . $whereSql
    . ' ORDER BY id DESC LIMIT ' . (int) $perPage . ' OFFSET ' . (int) $offset;
$st = $pdo->prepare($sql);
$st->execute($params);
$rows = $st->fetchAll(PDO::FETCH_ASSOC);

$fromRow = $totalRows === 0 ? 0 : $offset + 1;
$toRow = $totalRows === 0 ? 0 : min($offset + count($rows), $totalRows);

$base = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/\\');
$usersSelf = ($base === '' || $base === '.') ? 'users.php' : $base . '/users.php';

$usersUrl = static function (array $overrides = []) use ($usersSelf, $filter, $search, $page): string {
    $query = [];
    $status = array_key_exists('status', $overrides) ? (string) $overrides['status'] : $filter;
    $q = array_key_exists('q', $overrides) ? (string) $overrides['q'] : $search;
    $p = array_key_exists('page', $overrides) ? (int) $overrides['page'] : $page;
    if ($status !== 'all') {
        $query['status'] = $status;
    }
    if ($q !== '') {
        $query['q'] = $q;
    }
    if ($p > 1) {
        $query['page'] = $p;
    }
    return $usersSelf . ($query !== [] ? ('?' . http_build_query($query)) : '');
};

$userChipTones = [
    'all' => 'brand',
    'pending_verification' => 'warning',
    'verified' => 'success',
    'declined' => 'danger',
    'pending_otp' => 'neutral',
];
$userChip = static function (string $key, string $label, string $cur) use ($usersUrl, $userChipTones): string {
    $tone = $userChipTones[$key] ?? 'brand';

    return ww_admin_filter_chip($usersUrl(['status' => $key, 'page' => 1]), $label, $cur === $key, $tone);
};

$userPhp = ($base === '' || $base === '.') ? 'user.php' : $base . '/user.php';

require __DIR__ . '/partials/head.php';
require __DIR__ . '/partials/sidebar.php';
require __DIR__ . '/partials/shell_open.php';
?>

<?php if (isset($_GET['suspended']) && $_GET['suspended'] === '1'): ?>
  <div class="mb-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-medium text-amber-900">User suspended — they are now pending verification and have been signed out of the app.</div>
<?php endif; ?>
<?php if (isset($_GET['deleted']) && $_GET['deleted'] === '1'): ?>
  <div class="mb-4 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-800">User account deleted permanently.</div>
<?php endif; ?>
<?php require __DIR__ . '/partials/user_otp_flash.php'; ?>

<div class="rounded-2xl border border-slate-100 bg-white shadow-panel overflow-hidden">
  <div class="border-b border-slate-100 px-6 py-4 space-y-4">
    <div>
      <h2 class="text-base font-semibold text-slate-900">App users</h2>
      <p class="text-sm text-slate-500">Open a user to review signup details and approve or decline.</p>
    </div>
    <form method="get" class="flex w-full max-w-xl flex-col gap-2 sm:flex-row">
      <?php if ($filter !== 'all'): ?>
        <input type="hidden" name="status" value="<?= htmlspecialchars($filter, ENT_QUOTES, 'UTF-8') ?>" />
      <?php endif; ?>
      <label class="sr-only" for="user-search">Search users</label>
      <input
        id="user-search"
        type="search"
        name="q"
        value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>"
        placeholder="Search name, username, email, or phone"
        class="min-w-0 flex-1 rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
      />
      <button type="submit" class="admin-btn admin-btn--primary">Search</button>
      <?php if ($search !== ''): ?>
        <a href="<?= htmlspecialchars($usersUrl(['q' => '', 'page' => 1]), ENT_QUOTES, 'UTF-8') ?>" class="admin-btn admin-btn--soft">Clear</a>
      <?php endif; ?>
    </form>
    <p class="text-xs text-slate-500">
      <?php if ($search !== ''): ?>
        <?= (int) $totalRows ?> result<?= $totalRows === 1 ? '' : 's' ?> for “<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>”
        <?php if ($totalRows > 0): ?>
          · showing <?= (int) $fromRow ?>–<?= (int) $toRow ?>
        <?php endif; ?>
      <?php else: ?>
        <?= (int) $totalRows ?> user<?= $totalRows === 1 ? '' : 's' ?>
        <?php if ($totalRows > 0): ?>
          · showing <?= (int) $fromRow ?>–<?= (int) $toRow ?>
        <?php endif; ?>
      <?php endif; ?>
    </p>
    <div class="flex flex-wrap gap-2">
      <?= $userChip('all', 'All', $filter) ?>
      <?= $userChip('pending_verification', 'Pending verification', $filter) ?>
      <?= $userChip('verified', 'Verified', $filter) ?>
      <?= $userChip('declined', 'Declined', $filter) ?>
      <?= $userChip('pending_otp', 'Pending OTP', $filter) ?>
    </div>
  </div>
  <div class="overflow-x-auto">
    <table class="min-w-full text-left text-sm">
      <thead class="border-b border-slate-100 bg-slate-50 text-xs font-semibold uppercase tracking-wider text-slate-500">
        <tr>
          <th class="px-6 py-3">User</th>
          <th class="px-6 py-3">Email</th>
          <th class="px-6 py-3">Status</th>
          <th class="px-6 py-3">Joined</th>
          <th class="px-6 py-3 text-right">Actions</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-100">
        <?php foreach ($rows as $r): ?>
          <?php
            $uid = (int) $r['id'];
            $rowUser = $r;
            $rowUser['id'] = $uid;
            $rowName = trim((string) $r['first_name'] . ' ' . (string) $r['last_name']);
            if ($rowName === '') {
                $rowName = (string) $r['email'];
            }
            $rowCanSuspend = ww_admin_can_suspend_user($rowUser);
            $rowCanDelete = ww_admin_can_delete_user($pdo, $rowUser);
          ?>
          <tr class="bg-white hover:bg-brand-muted/20"<?= ww_admin_row_attrs((string) $r['status']) ?>>
            <td class="px-6 py-4 font-medium text-slate-900">
              <?= htmlspecialchars((string) $r['first_name'] . ' ' . (string) $r['last_name'], ENT_QUOTES, 'UTF-8') ?>
              <div class="text-xs font-normal text-slate-500">@<?= htmlspecialchars((string) $r['username'], ENT_QUOTES, 'UTF-8') ?></div>
            </td>
            <td class="px-6 py-4 text-slate-600"><?= htmlspecialchars((string) $r['email'], ENT_QUOTES, 'UTF-8') ?></td>
            <td class="px-6 py-4"><?= ww_admin_status_badge((string) $r['status']) ?></td>
            <td class="px-6 py-4 text-slate-500"><?= htmlspecialchars((string) $r['created_at'], ENT_QUOTES, 'UTF-8') ?></td>
            <td class="px-6 py-4 text-right">
              <div class="flex flex-wrap items-center justify-end gap-2">
                <button type="button" class="admin-btn admin-btn--primary admin-btn--sm js-user-modal-open" data-user-id="<?= $uid ?>">View</button>
                <?php if ($rowCanSuspend): ?>
                  <button type="button" class="admin-btn admin-btn--warning admin-btn--sm js-admin-user-suspend" data-user-id="<?= $uid ?>" data-user-name="<?= htmlspecialchars($rowName, ENT_QUOTES, 'UTF-8') ?>" data-return="users">Suspend</button>
                <?php endif; ?>
                <?php if ($rowCanDelete): ?>
                  <button type="button" class="admin-btn admin-btn--danger admin-btn--sm js-admin-user-delete" data-user-id="<?= $uid ?>" data-user-name="<?= htmlspecialchars($rowName, ENT_QUOTES, 'UTF-8') ?>" data-return="users">Delete</button>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if ($rows === []): ?>
          <tr><td colspan="5" class="px-6 py-8 text-center text-slate-500"><?= $search !== '' ? 'No users match your search.' : 'No users yet.' ?></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if ($totalPages > 1): ?>
    <div class="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 px-6 py-4">
      <p class="text-xs text-slate-500">Page <?= (int) $page ?> of <?= (int) $totalPages ?></p>
      <div class="flex flex-wrap items-center gap-2">
        <?php if ($page > 1): ?>
          <a href="<?= htmlspecialchars($usersUrl(['page' => $page - 1]), ENT_QUOTES, 'UTF-8') ?>" class="admin-btn admin-btn--soft admin-btn--sm">← Previous</a>
        <?php else: ?>
          <span class="admin-btn admin-btn--soft admin-btn--sm pointer-events-none opacity-40">← Previous</span>
        <?php endif; ?>
        <?php
        $windowStart = max(1, $page - 2);
        $windowEnd = min($totalPages, $page + 2);
        if ($windowStart > 1): ?>
          <a href="<?= htmlspecialchars($usersUrl(['page' => 1]), ENT_QUOTES, 'UTF-8') ?>" class="admin-btn admin-btn--soft admin-btn--sm">1</a>
          <?php if ($windowStart > 2): ?><span class="px-1 text-xs text-slate-400">…</span><?php endif; ?>
        <?php endif; ?>
        <?php for ($p = $windowStart; $p <= $windowEnd; $p++): ?>
          <?php if ($p === $page): ?>
            <span class="admin-btn admin-btn--primary admin-btn--sm pointer-events-none"><?= (int) $p ?></span>
          <?php else: ?>
            <a href="<?= htmlspecialchars($usersUrl(['page' => $p]), ENT_QUOTES, 'UTF-8') ?>" class="admin-btn admin-btn--soft admin-btn--sm"><?= (int) $p ?></a>
          <?php endif; ?>
        <?php endfor; ?>
        <?php if ($windowEnd < $totalPages): ?>
          <?php if ($windowEnd < $totalPages - 1): ?><span class="px-1 text-xs text-slate-400">…</span><?php endif; ?>
          <a href="<?= htmlspecialchars($usersUrl(['page' => $totalPages]), ENT_QUOTES, 'UTF-8') ?>" class="admin-btn admin-btn--soft admin-btn--sm"><?= (int) $totalPages ?></a>
        <?php endif; ?>
        <?php if ($page < $totalPages): ?>
          <a href="<?= htmlspecialchars($usersUrl(['page' => $page + 1]), ENT_QUOTES, 'UTF-8') ?>" class="admin-btn admin-btn--soft admin-btn--sm">Next →</a>
        <?php else: ?>
          <span class="admin-btn admin-btn--soft admin-btn--sm pointer-events-none opacity-40">Next →</span>
        <?php endif; ?>
      </div>
    </div>
  <?php endif; ?>
</div>

<div id="user-review-modal" class="fixed inset-0 z-50 hidden" role="dialog" aria-modal="true" aria-labelledby="user-review-modal-title">
  <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-[2px] js-user-modal-backdrop" aria-hidden="true"></div>
  <div class="absolute inset-0 flex items-center justify-center p-4 pointer-events-none">
    <div class="pointer-events-auto w-full max-w-2xl max-h-[min(90vh,800px)] flex flex-col rounded-2xl border border-slate-200 bg-white shadow-2xl shadow-slate-900/20">
      <div class="flex shrink-0 items-center justify-between gap-3 border-b border-slate-100 px-5 py-4">
        <h2 id="user-review-modal-title" class="text-base font-semibold text-slate-900">User details</h2>
        <button type="button" class="rounded-lg p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-800 js-user-modal-close" aria-label="Close">
          <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>
      </div>
      <div id="user-review-modal-body" class="min-h-0 flex-1 overflow-y-auto px-5 py-4 text-left">
        <div class="flex items-center justify-center py-12 text-sm text-slate-500">Loading…</div>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
  var modal = document.getElementById('user-review-modal');
  var bodyEl = document.getElementById('user-review-modal-body');
  if (!modal || !bodyEl) return;

  function openModal() {
    modal.classList.remove('hidden');
    document.documentElement.classList.add('overflow-hidden');
  }
  function closeModal() {
    modal.classList.add('hidden');
    document.documentElement.classList.remove('overflow-hidden');
    bodyEl.innerHTML = '<div class="flex items-center justify-center py-12 text-sm text-slate-500">Loading…</div>';
  }

  modal.querySelectorAll('.js-user-modal-close, .js-user-modal-backdrop').forEach(function (el) {
    el.addEventListener('click', closeModal);
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && !modal.classList.contains('hidden')) closeModal();
  });

  document.querySelectorAll('.js-user-modal-open').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var id = btn.getAttribute('data-user-id');
      if (!id) return;
      openModal();
      bodyEl.innerHTML = '<div class="flex items-center justify-center py-12 text-sm text-slate-500">Loading…</div>';
      fetch('user_modal.php?id=' + encodeURIComponent(id), { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(function (r) { return r.text(); })
        .then(function (html) { bodyEl.innerHTML = html; })
        .catch(function () {
          bodyEl.innerHTML = '<p class="text-sm text-red-600">Could not load user. Try again or open the full page from the list.</p>';
        });
    });
  });
})();
</script>

<?php
$confirmModalUserPhp = $userPhp;
require __DIR__ . '/partials/user_confirm_modal.php';
?>
<script src="<?= htmlspecialchars(($base === '' || $base === '.' ? '' : $base) . '/assets/admin-user-actions.js', ENT_QUOTES, 'UTF-8') ?>"></script>
<script>
(function () {
  var m = document.getElementById('admin-user-confirm-modal');
  if (m) m.setAttribute('data-user-php-base', <?= json_encode($userPhp, JSON_THROW_ON_ERROR) ?>);
})();
</script>

<?php require __DIR__ . '/partials/shell_close.php'; ?>
