<?php

declare(strict_types=1);

header('Location: moderation.php');
exit;
