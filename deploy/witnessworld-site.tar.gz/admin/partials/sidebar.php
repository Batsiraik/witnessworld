<?php
/** @var string $activeNav */
$activeNav = $activeNav ?? '';
/** @var array{id:int,username:string,name:string,email:string,is_super:bool}|null $currentAdmin */
$cu = $currentAdmin ?? [];
$navClass = static function (string $key) use ($activeNav): string {
    $base = 'flex items-center gap-3 rounded-r-lg border-l-[3px] px-3 py-2.5 text-sm font-medium transition hover:bg-white/5 hover:text-white ';
    return $base . ($activeNav === $key
        ? 'border-brand bg-brand/15 text-white'
        : 'border-transparent text-slate-300');
};
$base = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/\\');
if ($base === '' || $base === '.') {
    $base = '';
}
$home = $base === '' ? 'index.php' : $base . '/index.php';
$users = $base === '' ? 'users.php' : $base . '/users.php';
$businesses = $base === '' ? 'businesses.php' : $base . '/businesses.php';
$settings = $base === '' ? 'settings.php' : $base . '/settings.php';
$contentHub = $base === '' ? 'content.php' : $base . '/content.php';
$categoriesHub = $base === '' ? 'categories.php' : $base . '/categories.php';
$featuredListings = $base === '' ? 'featured_listings.php' : $base . '/featured_listings.php';
$createContent = $base === '' ? 'create_content.php' : $base . '/create_content.php';
$storeAddProducts = $base === '' ? 'store_add_products.php' : $base . '/store_add_products.php';
$commerceRequests = $base === '' ? 'commerce_requests.php' : $base . '/commerce_requests.php';
$moderation = $base === '' ? 'moderation.php' : $base . '/moderation.php';
$admins = $base === '' ? 'admins.php' : $base . '/admins.php';
$pushNotifications = $base === '' ? 'push_notifications.php' : $base . '/push_notifications.php';
$customerSupport = $base === '' ? 'customer_support.php' : $base . '/customer_support.php';
$analyticsPage = $base === '' ? 'analytics.php' : $base . '/analytics.php';
$logout = $base === '' ? 'logout.php' : $base . '/logout.php';
$isSuper = !empty($cu['is_super']);
?>
<div
  id="admin-sidebar-backdrop"
  class="fixed inset-0 z-40 bg-slate-900/60 opacity-0 pointer-events-none transition-opacity duration-300 lg:hidden"
  aria-hidden="true"
></div>
<aside
  id="admin-sidebar"
  class="fixed inset-y-0 left-0 z-50 flex w-[min(18rem,88vw)] max-w-xs -translate-x-full flex-col border-r border-white/10 bg-[#0f2847] text-slate-200 shadow-xl transition-transform duration-300 ease-out lg:z-40 lg:w-64 lg:max-w-none lg:translate-x-0"
  aria-label="Admin navigation"
>
  <div class="flex h-16 shrink-0 items-center gap-3 border-b border-white/10 px-4">
    <img src="assets/logo.jpg" alt="Witness World Connect" class="h-10 w-10 rounded-lg object-cover ring-1 ring-white/10" width="40" height="40" />
    <div class="min-w-0 flex-1">
      <p class="truncate text-sm font-semibold text-white">Witness World</p>
      <p class="truncate text-xs text-slate-400">Admin</p>
    </div>
    <button
      type="button"
      id="admin-sidebar-close"
      class="lg:hidden flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-slate-300 hover:bg-white/10 hover:text-white"
      aria-label="Close menu"
    >
      <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
    </button>
  </div>
  <nav class="flex-1 space-y-1 overflow-y-auto px-3 py-4" aria-label="Main">
    <p class="px-3 pb-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500">Menu</p>
    <a href="<?= htmlspecialchars($home, ENT_QUOTES, 'UTF-8') ?>"
       class="<?= htmlspecialchars($navClass('dashboard'), ENT_QUOTES, 'UTF-8') ?>">
      <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-brand" aria-hidden="true">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
      </span>
      Dashboard
    </a>
    <a href="<?= htmlspecialchars($users, ENT_QUOTES, 'UTF-8') ?>"
       class="<?= htmlspecialchars($navClass('users'), ENT_QUOTES, 'UTF-8') ?>">
      <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-brand" aria-hidden="true">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
      </span>
      App users
    </a>
    <a href="<?= htmlspecialchars($businesses, ENT_QUOTES, 'UTF-8') ?>"
       class="<?= htmlspecialchars($navClass('businesses'), ENT_QUOTES, 'UTF-8') ?>">
      <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-brand" aria-hidden="true">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
      </span>
      Businesses
    </a>
    <a href="<?= htmlspecialchars($customerSupport, ENT_QUOTES, 'UTF-8') ?>"
       class="<?= htmlspecialchars($navClass('support'), ENT_QUOTES, 'UTF-8') ?> flex items-center gap-3">
      <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-brand" aria-hidden="true">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/></svg>
      </span>
      Customer support
      <span id="admin-support-nav-badge" class="ml-auto hidden min-w-[1.25rem] rounded-full bg-red-500 px-1.5 text-center text-[10px] font-bold leading-5 text-white"></span>
    </a>
    <a href="<?= htmlspecialchars($contentHub, ENT_QUOTES, 'UTF-8') ?>"
       class="<?= htmlspecialchars($navClass('content'), ENT_QUOTES, 'UTF-8') ?>">
      <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-brand" aria-hidden="true">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
      </span>
      Listings &amp; content
    </a>
    <a href="<?= htmlspecialchars($categoriesHub, ENT_QUOTES, 'UTF-8') ?>"
       class="<?= htmlspecialchars($navClass('categories'), ENT_QUOTES, 'UTF-8') ?>">
      <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-brand" aria-hidden="true">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"/></svg>
      </span>
      Categories
    </a>
    <a href="<?= htmlspecialchars($featuredListings, ENT_QUOTES, 'UTF-8') ?>"
       class="<?= htmlspecialchars($navClass('featured_listings'), ENT_QUOTES, 'UTF-8') ?>">
      <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-brand" aria-hidden="true">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
      </span>
      Featured listings
    </a>
    <a href="<?= htmlspecialchars($createContent, ENT_QUOTES, 'UTF-8') ?>"
       class="<?= htmlspecialchars($navClass('create_content'), ENT_QUOTES, 'UTF-8') ?>">
      <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-brand" aria-hidden="true">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
      </span>
      Add listing for user
    </a>
    <a href="<?= htmlspecialchars($storeAddProducts, ENT_QUOTES, 'UTF-8') ?>"
       class="<?= htmlspecialchars($navClass('store_add_products'), ENT_QUOTES, 'UTF-8') ?>">
      <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-brand" aria-hidden="true">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
      </span>
      Add store products
    </a>
    <a href="<?= htmlspecialchars($commerceRequests, ENT_QUOTES, 'UTF-8') ?>"
       class="<?= htmlspecialchars($navClass('commerce_requests'), ENT_QUOTES, 'UTF-8') ?>">
      <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-brand" aria-hidden="true">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 14l2 2 4-4M7 4h10a2 2 0 012 2v14l-4-2-4 2-4-2-4 2V6a2 2 0 012-2z"/></svg>
      </span>
      Commerce requests
    </a>
    <a href="<?= htmlspecialchars($moderation, ENT_QUOTES, 'UTF-8') ?>"
       class="<?= htmlspecialchars($navClass('moderation'), ENT_QUOTES, 'UTF-8') ?>">
      <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-brand" aria-hidden="true">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
      </span>
      Content reports
    </a>
    <a href="<?= htmlspecialchars($analyticsPage, ENT_QUOTES, 'UTF-8') ?>"
       class="<?= htmlspecialchars($navClass('analytics'), ENT_QUOTES, 'UTF-8') ?>">
      <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-brand" aria-hidden="true">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
      </span>
      Analytics
    </a>
    <a href="<?= htmlspecialchars($pushNotifications, ENT_QUOTES, 'UTF-8') ?>"
       class="<?= htmlspecialchars($navClass('push'), ENT_QUOTES, 'UTF-8') ?>">
      <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-brand" aria-hidden="true">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
      </span>
      Push notification
    </a>
    <a href="<?= htmlspecialchars($settings, ENT_QUOTES, 'UTF-8') ?>"
       class="<?= htmlspecialchars($navClass('settings'), ENT_QUOTES, 'UTF-8') ?>">
      <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-brand" aria-hidden="true">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
      </span>
      Settings
    </a>
    <?php if ($isSuper): ?>
    <a href="<?= htmlspecialchars($admins, ENT_QUOTES, 'UTF-8') ?>"
       class="<?= htmlspecialchars($navClass('admins'), ENT_QUOTES, 'UTF-8') ?>">
      <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-brand" aria-hidden="true">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197"/></svg>
      </span>
      Admins
    </a>
    <?php endif; ?>
  </nav>
  <div class="border-t border-white/10 p-4 space-y-2">
    <div class="rounded-xl bg-white/5 p-3 ring-1 ring-white/10">
      <p class="text-xs font-medium text-slate-400">Signed in</p>
      <p class="truncate text-sm font-semibold text-white"><?= htmlspecialchars((string) ($cu['name'] ?? ''), ENT_QUOTES, 'UTF-8') ?></p>
    </div>
    <a href="<?= htmlspecialchars($logout, ENT_QUOTES, 'UTF-8') ?>" class="block w-full rounded-xl border border-white/10 bg-white/5 py-2 text-center text-sm font-semibold text-white hover:bg-white/10">Log out</a>
  </div>
</aside>
