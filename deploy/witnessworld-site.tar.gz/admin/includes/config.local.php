<?php

return [
    'db_host' => 'srv1999.hstgr.io',
    'db_name' => 'u462861958_witnessworld',
    'db_user' => 'u462861958_witnessworld',
    'db_pass' => 'Witnessworld2026',
    'db_charset' => 'utf8mb4',
];
