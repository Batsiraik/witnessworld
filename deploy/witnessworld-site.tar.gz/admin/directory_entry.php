<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/guard.php';
require_once __DIR__ . '/includes/push_triggers.php';
require_once __DIR__ . '/../api/lib/directory_helpers.php';
require_once __DIR__ . '/includes/admin_create_content.php';

$apiConfig = dirname(__DIR__) . '/api/config.php';
if (is_file($apiConfig)) {
    require_once $apiConfig;
}

$id = (int) ($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ' . ww_admin_content_url('directory'));
    exit;
}

$pdo = witnessworld_pdo();
$adminId = (int) ($_SESSION['admin_id'] ?? 0);
$base = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/\\');

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $action = (string) ($_POST['action'] ?? '');
    $note = trim((string) ($_POST['admin_note'] ?? ''));
    try {
        $st = $pdo->prepare(
            'SELECT id, moderation_status, user_id, business_name FROM directory_entries WHERE id = ? LIMIT 1'
        );
        $st->execute([$id]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $now = date('Y-m-d H:i:s');
            if ($action === 'approve') {
                $pdo->prepare(
                    'UPDATE directory_entries SET moderation_status = ?, admin_note = NULL, reviewed_at = ?, reviewed_by_admin_id = ? WHERE id = ?'
                )->execute(['approved', $now, $adminId > 0 ? $adminId : null, $id]);
                ww_admin_notify_directory_review(
                    $pdo,
                    (int) $row['user_id'],
                    'approve',
                    (string) $row['business_name'],
                    $id
                );
            } elseif ($action === 'reject') {
                $pdo->prepare(
                    'UPDATE directory_entries SET moderation_status = ?, admin_note = ?, reviewed_at = ?, reviewed_by_admin_id = ? WHERE id = ?'
                )->execute(['rejected', $note !== '' ? $note : null, $now, $adminId > 0 ? $adminId : null, $id]);
                ww_admin_notify_directory_review(
                    $pdo,
                    (int) $row['user_id'],
                    'reject',
                    (string) $row['business_name'],
                    $id
                );
            } elseif ($action === 'suspend') {
                ww_content_suspend($pdo, 'directory', $id, $adminId, $note !== '' ? $note : null);
            } elseif ($action === 'reopen') {
                $pdo->prepare(
                    'UPDATE directory_entries SET moderation_status = ?, admin_note = NULL, reviewed_at = NULL, reviewed_by_admin_id = NULL WHERE id = ?'
                )->execute(['pending_approval', $id]);
            } elseif ($action === 'update_logo') {
                $newLogo = trim((string) ($_POST['logo_url'] ?? ''));
                if ($newLogo !== '') {
                    $pdo->prepare('UPDATE directory_entries SET logo_url = ? WHERE id = ?')->execute([$newLogo, $id]);
                }
                header('Location: directory_entry.php?id=' . $id . '&logo_updated=1');
                exit;
            } elseif ($action === 'delete') {
                if (ww_content_delete($pdo, 'directory', $id)) {
                    $returnTo = trim((string) ($_POST['return_to'] ?? ''));
                    ww_content_redirect_after_action('directory', $id, 'delete', $returnTo, $base);
                }
            }
        }
    } catch (Throwable) {
        header('Location: ' . ww_admin_content_url('directory'));
        exit;
    }
    $returnTo = trim((string) ($_POST['return_to'] ?? ''));
    ww_content_redirect_after_action('directory', $id, $action, $returnTo, $base);
}

$entry = null;
try {
    $st = $pdo->prepare(
        'SELECT d.*, u.email, u.first_name, u.last_name, u.username, u.status AS user_status,
                a.name AS reviewer_name, dc.name AS category_name
         FROM directory_entries d
         INNER JOIN users u ON u.id = d.user_id
         LEFT JOIN admins a ON a.id = d.reviewed_by_admin_id
         LEFT JOIN directory_categories dc ON dc.id = d.category_id
         WHERE d.id = ? LIMIT 1'
    );
    $st->execute([$id]);
    $entry = $st->fetch(PDO::FETCH_ASSOC);
} catch (Throwable) {
    header('Location: ' . ww_admin_content_url('directory'));
    exit;
}
if (!$entry) {
    header('Location: ' . ww_admin_content_url('directory'));
    exit;
}

$directoryBack = ww_admin_content_url('directory', $base);
$directoryReturn = ww_admin_content_return_token('directory');

$pageTitle = 'Directory · ' . (string) $entry['business_name'];
$activeNav = 'content';

$status = trim((string) ($entry['moderation_status'] ?? ''));
$cats = ww_directory_categories();
$catLabel = !empty($entry['category_name'])
    ? (string) $entry['category_name']
    : ($cats[(string) $entry['category']] ?? (string) $entry['category']);

require __DIR__ . '/partials/head.php';
require __DIR__ . '/partials/sidebar.php';
require __DIR__ . '/partials/shell_open.php';
?>

<div class="space-y-6">
  <div class="flex flex-wrap items-center justify-between gap-3">
    <div>
      <p class="text-sm text-slate-500"><a href="<?= htmlspecialchars($directoryBack, ENT_QUOTES, 'UTF-8') ?>" class="font-semibold text-brand hover:underline">← Back to directory</a></p>
      <h2 class="text-lg font-semibold text-slate-900"><?= htmlspecialchars((string) $entry['business_name'], ENT_QUOTES, 'UTF-8') ?></h2>
      <p class="text-sm text-slate-600">#<?= (int) $entry['id'] ?> · <?= htmlspecialchars($catLabel, ENT_QUOTES, 'UTF-8') ?></p>
    </div>
    <div class="text-sm font-semibold text-slate-700">Status: <span class="text-brand"><?= htmlspecialchars(str_replace('_', ' ', $status), ENT_QUOTES, 'UTF-8') ?></span></div>
  </div>

  <div class="rounded-2xl border border-slate-100 bg-white p-6 shadow-panel">
    <h3 class="text-sm font-semibold text-slate-900">Owner</h3>
    <p class="mt-2 text-sm text-slate-700">
      <?= htmlspecialchars(trim((string) $entry['first_name'] . ' ' . (string) $entry['last_name']), ENT_QUOTES, 'UTF-8') ?>
      <span class="text-slate-500">(@<?= htmlspecialchars((string) $entry['username'], ENT_QUOTES, 'UTF-8') ?>)</span>
    </p>
    <p class="text-sm text-slate-600"><?= htmlspecialchars((string) $entry['email'], ENT_QUOTES, 'UTF-8') ?></p>
    <p class="mt-3"><a class="text-sm font-semibold text-brand hover:underline" href="user.php?id=<?= (int) $entry['user_id'] ?>">Open user profile</a></p>
  </div>

  <?php if (isset($_GET['logo_updated']) && $_GET['logo_updated'] === '1'): ?>
    <div class="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-800">Logo updated.</div>
  <?php endif; ?>

  <div class="rounded-2xl border border-slate-100 bg-white p-6 shadow-panel">
    <h3 class="text-sm font-semibold text-slate-900">Logo</h3>
    <?php if (!empty($entry['logo_url'])): ?>
      <div class="mt-3">
        <a href="<?= htmlspecialchars((string) $entry['logo_url'], ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener">
          <img src="<?= htmlspecialchars((string) $entry['logo_url'], ENT_QUOTES, 'UTF-8') ?>" alt="" class="h-24 w-24 rounded-xl object-cover ring-1 ring-slate-100" loading="lazy" />
        </a>
      </div>
    <?php else: ?>
      <p class="mt-2 text-sm text-amber-700 font-medium">No logo uploaded.</p>
    <?php endif; ?>
    <div class="mt-4 space-y-2">
      <label class="block text-xs font-semibold text-slate-600"><?= !empty($entry['logo_url']) ? 'Replace logo' : 'Upload logo' ?></label>
      <input type="file" accept="image/*" id="dir-logo-file" class="text-sm" />
      <div id="dir-logo-status" class="text-xs text-slate-500"></div>
      <div id="dir-logo-preview-new" class="hidden">
        <img id="dir-logo-img-new" src="" alt="" class="h-16 w-16 rounded-xl object-cover ring-1 ring-slate-200" />
      </div>
      <form method="post" id="dir-logo-form">
        <input type="hidden" name="action" value="update_logo" />
        <input type="hidden" name="logo_url" id="dir-logo-url-hidden" value="" />
        <button type="submit" id="dir-logo-save" class="admin-btn admin-btn--primary admin-btn--sm hidden">Save logo</button>
      </form>
    </div>
  </div>

  <script>
  (function () {
    var fileInput = document.getElementById('dir-logo-file');
    var statusEl = document.getElementById('dir-logo-status');
    var previewWrap = document.getElementById('dir-logo-preview-new');
    var previewImg = document.getElementById('dir-logo-img-new');
    var hiddenUrl = document.getElementById('dir-logo-url-hidden');
    var saveBtn = document.getElementById('dir-logo-save');
    if (!fileInput) return;

    fileInput.addEventListener('change', function () {
      if (!this.files || !this.files[0]) return;
      statusEl.textContent = 'Uploading…';
      saveBtn.classList.add('hidden');
      previewWrap.classList.add('hidden');

      var fd = new FormData();
      fd.append('file', this.files[0]);
      fd.append('user_id', String(<?= (int) $entry['user_id'] ?>));
      fd.append('kind', 'directory');

      fetch('admin_media_upload.php', { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (data.ok && data.url) {
            hiddenUrl.value = data.url;
            previewImg.src = data.url;
            previewWrap.classList.remove('hidden');
            saveBtn.classList.remove('hidden');
            statusEl.textContent = 'Uploaded — click Save logo to apply.';
          } else {
            statusEl.textContent = data.error || 'Upload failed';
          }
        })
        .catch(function () { statusEl.textContent = 'Upload failed'; });
    });
  })();
  </script>

  <div class="rounded-2xl border border-slate-100 bg-white p-6 shadow-panel">
    <h3 class="text-sm font-semibold text-slate-900">Contact & location (public)</h3>
    <dl class="mt-4 grid gap-3 text-sm sm:grid-cols-2">
      <div><dt class="text-slate-500">Phone</dt><dd class="font-medium text-slate-900"><?= htmlspecialchars((string) $entry['phone'], ENT_QUOTES, 'UTF-8') ?></dd></div>
      <div><dt class="text-slate-500">Email</dt><dd class="font-medium text-slate-900 break-all"><?= htmlspecialchars((string) $entry['email'], ENT_QUOTES, 'UTF-8') ?></dd></div>
      <?php if (!empty($entry['website'])): ?>
        <div class="sm:col-span-2"><dt class="text-slate-500">Website</dt><dd><a class="font-semibold text-brand break-all hover:underline" href="<?= htmlspecialchars((string) $entry['website'], ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener"><?= htmlspecialchars((string) $entry['website'], ENT_QUOTES, 'UTF-8') ?></a></dd></div>
      <?php endif; ?>
      <?php if (!empty($entry['map_url'])): ?>
        <div class="sm:col-span-2"><dt class="text-slate-500">Map</dt><dd><a class="font-semibold text-brand break-all hover:underline" href="<?= htmlspecialchars((string) $entry['map_url'], ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener"><?= htmlspecialchars((string) $entry['map_url'], ENT_QUOTES, 'UTF-8') ?></a></dd></div>
      <?php endif; ?>
      <div class="sm:col-span-2">
        <dt class="text-slate-500">Address</dt>
        <dd class="font-medium text-slate-900">
          <?php
            $parts = array_filter([
                $entry['address_line'] ? (string) $entry['address_line'] : '',
                (string) $entry['city'],
                $entry['postal_code'] ? (string) $entry['postal_code'] : '',
                $entry['location_us_state'] ? (string) $entry['location_us_state'] : '',
                (string) $entry['location_country_name'],
            ]);
            echo htmlspecialchars(implode(' · ', $parts), ENT_QUOTES, 'UTF-8');
          ?>
        </dd>
      </div>
      <div><dt class="text-slate-500">Created</dt><dd class="font-medium text-slate-900"><?= htmlspecialchars((string) $entry['created_at'], ENT_QUOTES, 'UTF-8') ?></dd></div>
    </dl>
    <?php if (!empty($entry['tagline'])): ?>
      <p class="mt-4 text-sm font-medium text-slate-800"><?= htmlspecialchars((string) $entry['tagline'], ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>
    <?php if (!empty($entry['description'])): ?>
      <p class="mt-3 text-xs font-semibold uppercase text-slate-500">Description</p>
      <p class="mt-1 whitespace-pre-wrap text-sm text-slate-800"><?= htmlspecialchars((string) $entry['description'], ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>
    <?php if (!empty($entry['hours_text'])): ?>
      <p class="mt-4 text-xs font-semibold uppercase text-slate-500">Hours</p>
      <p class="mt-1 whitespace-pre-wrap text-sm text-slate-800"><?= htmlspecialchars((string) $entry['hours_text'], ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>
    <?php if (!empty($entry['admin_note'])): ?>
      <div class="mt-4 rounded-xl border border-amber-200 bg-amber-50/80 p-4">
        <p class="text-xs font-semibold uppercase text-amber-900">Admin note</p>
        <p class="mt-1 text-sm text-amber-950 whitespace-pre-wrap"><?= htmlspecialchars((string) $entry['admin_note'], ENT_QUOTES, 'UTF-8') ?></p>
      </div>
    <?php endif; ?>
    <?php if (!empty($entry['reviewed_at'])): ?>
      <p class="mt-3 text-xs text-slate-500">Last reviewed <?= htmlspecialchars((string) $entry['reviewed_at'], ENT_QUOTES, 'UTF-8') ?><?php if (!empty($entry['reviewer_name'])): ?> · <?= htmlspecialchars((string) $entry['reviewer_name'], ENT_QUOTES, 'UTF-8') ?><?php endif; ?></p>
    <?php endif; ?>
  </div>

  <div class="rounded-2xl border border-slate-100 bg-white p-6 shadow-panel">
    <h3 class="text-sm font-semibold text-slate-900">Moderation</h3>
    <p class="mt-1 text-sm text-slate-500">Approve to show in the app directory. Suspend to hide without deleting.</p>

    <?php if ($status === 'pending_approval'): ?>
      <div class="mt-4 rounded-xl border border-emerald-200 bg-emerald-50/90 px-4 py-3 text-sm text-emerald-950">
        <p class="font-semibold">Pending approval</p>
        <p class="mt-1">Use <span class="font-semibold">Approve listing</span> below to publish to the directory.</p>
      </div>
    <?php elseif ($status === 'rejected'): ?>
      <div class="mt-4 rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-800">
        <p class="font-semibold">Rejected</p>
        <p class="mt-1">You can approve if the owner corrected their submission.</p>
      </div>
    <?php endif; ?>

    <?php if ($status === 'pending_approval' || $status === 'rejected'): ?>
      <form method="post" class="mt-4 space-y-4">
        <div>
          <label class="block text-xs font-semibold text-slate-600" for="admin_note">Note</label>
          <textarea id="admin_note" name="admin_note" rows="3" class="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"></textarea>
        </div>
        <div class="flex flex-wrap gap-3">
          <button type="submit" name="action" value="approve" class="rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-emerald-700">Approve listing</button>
          <button type="submit" name="action" value="reject" class="rounded-xl bg-slate-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-slate-800">Reject</button>
          <button type="submit" name="action" value="suspend" class="admin-btn admin-btn--warning px-5 py-2.5 text-sm" onclick="return confirm('Suspend this listing?');">Suspend</button>
        </div>
      </form>
    <?php elseif ($status === 'approved'): ?>
      <form method="post" class="mt-4 space-y-4">
        <div>
          <label class="block text-xs font-semibold text-slate-600" for="admin_note">Note (optional)</label>
          <textarea id="admin_note" name="admin_note" rows="2" class="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"></textarea>
        </div>
        <div class="flex flex-wrap gap-3">
          <button type="submit" name="action" value="suspend" class="admin-btn admin-btn--warning px-5 py-2.5 text-sm" onclick="return confirm('Suspend?');">Suspend</button>
          <button type="submit" name="action" value="reject" class="rounded-xl border border-slate-200 bg-white px-5 py-2.5 text-sm font-semibold text-slate-800 hover:bg-slate-50">Reject instead</button>
        </div>
      </form>
    <?php elseif ($status === 'suspended'): ?>
      <p class="mt-3 text-sm text-slate-600">Suspended — not shown in the directory.</p>
      <form method="post" class="mt-4">
        <button type="submit" name="action" value="reopen" class="rounded-xl border border-brand bg-brand/10 px-5 py-2.5 text-sm font-semibold text-brand-dark hover:bg-brand/15">Reopen as pending</button>
      </form>
    <?php else: ?>
      <p class="mt-3 text-sm text-amber-800">Unknown status. Check database.</p>
    <?php endif; ?>
  </div>
</div>

<?php
$contentRow = $entry;
$entityType = 'directory';
$entityId = $id;
require __DIR__ . '/partials/content_detail_controls.php';
require __DIR__ . '/partials/content_confirm_scripts.php';
?>
<?php require __DIR__ . '/partials/shell_close.php'; ?>
