<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/lib/user_tokens.php';
require_once __DIR__ . '/lib/listing_helpers.php';
require_once __DIR__ . '/lib/subscription_helpers.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    ww_json(['ok' => false, 'error' => 'Method not allowed'], 405);
}

$tok = ww_bearer_token();
if (!$tok) {
    ww_json(['ok' => false, 'error' => 'Unauthorized'], 401);
}

$pdo = witnessworld_pdo();
$user = ww_user_from_token($pdo, $tok);
if (!$user) {
    ww_json(['ok' => false, 'error' => 'Unauthorized'], 401);
}

if (($user['status'] ?? '') !== 'verified') {
    ww_json(['ok' => false, 'error' => 'Account must be verified to post a listing'], 403);
}
ww_subscription_require_posting($pdo, $user);
ww_subscription_enforce_listing_cap($pdo, $user);

$avatar = trim((string) ($user['avatar_url'] ?? ''));
if ($avatar === '') {
    ww_json(['ok' => false, 'error' => 'Upload a profile photo in Profile & settings before posting a listing'], 422);
}

$userId = (int) $user['id'];
$body = ww_read_json();

$listingType = strtolower(trim((string) ($body['listing_type'] ?? '')));
if (!in_array($listingType, ['classified', 'service', 'community'], true)) {
    ww_json(['ok' => false, 'error' => 'listing_type must be classified, service, or community'], 422);
}

$categoryId = null;
$isFree = 0;
$priceAmount = null;
$pricingType = 'none';
$currency = 'USD';

if (in_array($listingType, ['classified', 'service', 'community'], true)) {
    $catTables = ['classified' => 'marketplace_categories', 'service' => 'service_categories', 'community' => 'community_categories'];
    $catTable = $catTables[$listingType];
    $catIn = isset($body['category_id']) ? (int) $body['category_id'] : 0;
    if ($catIn > 0) {
        $catCheck = $pdo->prepare("SELECT id FROM {$catTable} WHERE id = ? AND is_active = 1 LIMIT 1");
        $catCheck->execute([$catIn]);
        if ($catCheck->fetchColumn()) {
            $categoryId = $catIn;
        } else {
            ww_json(['ok' => false, 'error' => 'Invalid category'], 422);
        }
    }

    if ($listingType === 'classified') {
        $isFree = !empty($body['is_free']) ? 1 : 0;
        if (!$isFree) {
            $priceIn = isset($body['price_amount']) ? trim((string) $body['price_amount']) : '';
            if ($priceIn !== '' && is_numeric($priceIn) && (float) $priceIn >= 0) {
                $priceAmount = number_format((float) $priceIn, 2, '.', '');
                $pricingType = 'fixed';
            }
        }
        $currIn = strtoupper(trim((string) ($body['currency'] ?? 'USD')));
        if (strlen($currIn) === 3) $currency = $currIn;
    }
}

$title = trim((string) ($body['title'] ?? ''));
if ($title === '' || mb_strlen($title) > 255) {
    ww_json(['ok' => false, 'error' => 'Title is required (max 255 characters)'], 422);
}

$description = trim((string) ($body['description'] ?? ''));
if ($description === '' || mb_strlen($description) > 12000) {
    ww_json(['ok' => false, 'error' => 'Description is required (max 12000 characters)'], 422);
}

$mediaUrl = trim((string) ($body['media_url'] ?? ''));
if ($mediaUrl === '' || !ww_listing_url_belongs_to_user($mediaUrl, $userId)) {
    ww_json(['ok' => false, 'error' => 'Main image is required — upload through the app'], 422);
}

$videoUrl = trim((string) ($body['video_url'] ?? ''));
if ($videoUrl !== '' && !ww_listing_url_belongs_to_user($videoUrl, $userId)) {
    ww_json(['ok' => false, 'error' => 'Invalid video URL'], 422);
}

$portfolioIn = $body['portfolio_urls'] ?? [];
if (!is_array($portfolioIn)) {
    ww_json(['ok' => false, 'error' => 'portfolio_urls must be an array'], 422);
}
$portfolio = [];
foreach ($portfolioIn as $u) {
    $u = trim((string) $u);
    if ($u === '') {
        continue;
    }
    if (!ww_listing_url_belongs_to_user($u, $userId)) {
        ww_json(['ok' => false, 'error' => 'Invalid portfolio image URL'], 422);
    }
    $portfolio[] = $u;
    if (count($portfolio) > 12) {
        ww_json(['ok' => false, 'error' => 'At most 12 portfolio images'], 422);
    }
}

$skillsIn = $body['soft_skills'] ?? [];
if (!is_array($skillsIn)) {
    ww_json(['ok' => false, 'error' => 'soft_skills must be an array'], 422);
}
$skills = [];
foreach ($skillsIn as $s) {
    $s = trim((string) $s);
    if ($s === '') {
        continue;
    }
    if (mb_strlen($s) > 60) {
        ww_json(['ok' => false, 'error' => 'Each soft skill must be 60 characters or less'], 422);
    }
    $skills[] = $s;
    if (count($skills) > 24) {
        ww_json(['ok' => false, 'error' => 'At most 24 soft skills'], 422);
    }
}

$countryCode = strtoupper(trim((string) ($body['location_country_code'] ?? '')));
$countryMap = ww_listing_country_map();
if ($countryCode === '' || !isset($countryMap[$countryCode])) {
    ww_json(['ok' => false, 'error' => 'Select a valid country'], 422);
}
$countryName = $countryMap[$countryCode];

$usStateName = null;
if ($countryCode === 'US') {
    $stateCode = strtoupper(trim((string) ($body['location_us_state_code'] ?? '')));
    $stateMap = ww_listing_us_state_map();
    if ($stateCode === '' || !isset($stateMap[$stateCode])) {
        ww_json(['ok' => false, 'error' => 'Select a U.S. state'], 422);
    }
    $usStateName = $stateMap[$stateCode];
}

$portfolioJson = $portfolio === [] ? null : json_encode($portfolio, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
$skillsJson = $skills === [] ? null : json_encode($skills, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
$videoDb = $videoUrl !== '' ? $videoUrl : null;

try {
    $ins = $pdo->prepare(
        'INSERT INTO listings (
            user_id, listing_type, category_id, title, description,
            price_amount, is_free, pricing_type, currency,
            media_url, video_url, portfolio_urls_json, soft_skills_json,
            location_country_code, location_country_name, location_us_state,
            moderation_status
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
    );
    $ins->execute([
        $userId,
        $listingType,
        $categoryId,
        $title,
        $description,
        $priceAmount,
        $isFree,
        $pricingType,
        $currency,
        $mediaUrl,
        $videoDb,
        $portfolioJson,
        $skillsJson,
        $countryCode,
        $countryName,
        $usStateName,
        'pending_approval',
    ]);
} catch (Throwable $e) {
    $msg = $e->getMessage();
    if (str_contains($msg, 'Unknown column') || str_contains($msg, "doesn't exist")) {
        ww_json([
            'ok' => false,
            'error' => 'Database is missing listing columns. See database/README.md.',
        ], 500);
    }
    throw $e;
}

$newId = (int) $pdo->lastInsertId();

require_once __DIR__ . '/../admin/includes/admin_notifications.php';
ww_admin_alert_pending_listing($pdo, $newId, $title, $listingType, $userId);

ww_json([
    'ok' => true,
    'listing_id' => $newId,
    'message' => 'Your listing was submitted for review. You will see it in the marketplace after an admin approves it.',
]);
