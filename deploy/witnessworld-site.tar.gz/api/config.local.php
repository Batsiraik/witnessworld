<?php

declare(strict_types=1);

/**
 * Copy this file to api/config.local.php on each environment.
 * Do not commit api/config.local.php.
 */

define('WW_STRIPE_SECRET_KEY', 'sk_test_51Qah4CD8R3HWw5cclTzRLDWbMsWCg9ZDbQICUMCJDRBrquzd9nV32YOwU9h68qaKkLsTTtzSjZI0ABnWQYxXPuLd00m3Wej2qP');
