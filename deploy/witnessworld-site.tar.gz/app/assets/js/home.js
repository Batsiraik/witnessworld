/**
 * Home page — feed, location filter, search.
 */
(function () {
  const { apiGet, resolveMediaUrl } = window.WWC_API;

  const TOP_CATEGORIES = [
    {
      label: 'Professional services',
      href: 'services.html',
      bg: '#f3e8ff',
      color: '#7c3aed',
      svg: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z"/></svg>',
    },
    {
      label: 'Business directory',
      href: 'directory.html',
      bg: '#dcfce7',
      color: '#15803d',
      svg: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 21h18M5 21V7l8-4v18M19 21V11l-6-3"/><path d="M9 9v.01M9 12v.01M9 15v.01M9 18v.01"/></svg>',
    },
    {
      label: 'Marketplace',
      href: 'classifieds.html',
      bg: '#e8f4fd',
      color: '#1d4ed8',
      svg: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><path d="M3 6h18M16 10a4 4 0 01-8 0"/></svg>',
    },
    {
      label: 'Classifieds',
      href: 'community.html',
      bg: '#fef3c7',
      color: '#b45309',
      svg: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>',
    },
    {
      label: 'Online stores',
      href: 'stores.html',
      bg: '#ffedd5',
      color: '#c2410c',
      svg: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><path d="M9 22V12h6v10"/></svg>',
    },
  ];

  /** Max cards per home feed section — use “See all” for the full browse page. */
  const HOME_RAIL_LIMIT = 4;
  const FEED_FETCH_TIMEOUT_MS = 15_000;

  let booted = false;
  let countries = [];
  let usStates = [];
  let country = null;
  let usState = null;
  let feed = null;

  const els = {
    locBtn: document.getElementById('home-loc-btn'),
    locLabel: document.getElementById('home-loc-label'),
    search: document.getElementById('home-search'),
    cats: document.getElementById('home-cats'),
    feed: document.getElementById('home-feed'),
    locModal: document.getElementById('loc-modal'),
    locCountrySearch: document.getElementById('loc-country-search'),
    locCountryList: document.getElementById('loc-country-list'),
    locStateSection: document.getElementById('loc-state-section'),
    locStateList: document.getElementById('loc-state-list'),
  };

  function formatListingLoc(row) {
    const parts = [row.location_us_state, row.location_country_name].filter(Boolean);
    return parts.join(', ') || 'Location not set';
  }

  function formatDirLoc(row) {
    const parts = [row.city, row.location_us_state].filter(Boolean);
    return parts.join(', ') || formatListingLoc(row);
  }

  function locationLabel() {
    if (!country) return 'All locations';
    if (country.code === 'US' && usState) return `${usState.name}, ${country.name}`;
    return country.name;
  }

  function normalizeFeatured(raw) {
    if (!Array.isArray(raw)) return [];
    const out = [];
    for (const row of raw) {
      if (!row || typeof row !== 'object') continue;
      const kind = String(row.kind ?? '');
      if (kind === 'product' && row.product) out.push({ kind: 'product', product: row.product });
      else if (['service', 'classified', 'community'].includes(kind) && row.listing) {
        out.push({ kind, listing: row.listing });
      }
    }
    return out;
  }

  function normalizeFeed(raw) {
    if (!raw || typeof raw !== 'object') {
      return { services: [], products: [], classifieds: [], community: [], stores: [], directory: [], featured: [] };
    }
    const arr = (k) => (Array.isArray(raw[k]) ? raw[k] : []);
    return {
      services: arr('services'),
      products: arr('products'),
      classifieds: arr('classifieds'),
      community: arr('community'),
      stores: arr('stores'),
      directory: arr('directory'),
      featured: normalizeFeatured(raw.featured),
    };
  }

  function imgHtml(url, placeholderIcon) {
    const src = resolveMediaUrl(url);
    if (src) {
      return `<img src="${escapeAttr(src)}" alt="" loading="lazy" />`;
    }
    return `<div class="wwc-card-placeholder"><ion-icon name="${placeholderIcon}" aria-hidden="true"></ion-icon></div>`;
  }

  function flagsHtml(urgent, verified) {
    if (!urgent && !verified) return '';
    let html = '<div class="wwc-card-flags">';
    if (urgent) html += '<span class="wwc-flag wwc-flag-urgent">Urgent</span>';
    if (verified) html += '<span class="wwc-flag wwc-flag-verified">Verified</span>';
    html += '</div>';
    return html;
  }

  function cardListing(row, href) {
    const id = Number(row.id);
    const title = escapeHtml(String(row.title ?? ''));
    const media = row.media_url;
    const price = row.price_amount != null ? String(row.price_amount) : null;
    const cur = String(row.currency ?? 'USD');
    const pt = String(row.pricing_type ?? 'fixed');
    const loc = escapeHtml(formatListingLoc(row));
    const featured = row.is_featured === true;
    const urgent = row.is_urgent === true;
    const verified = row.is_verified === true;
    const priceHtml = price
      ? `<p class="wwc-card-price">${cur} ${escapeHtml(price)}${pt === 'hourly' ? '/hr' : ''}</p>`
      : `<p class="wwc-card-meta">See listing</p>`;

    return `
      <a href="${href}?id=${id}" class="wwc-card${featured ? ' is-featured' : ''}${urgent ? ' is-urgent' : ''}">
        <div class="wwc-card-img-wrap">
          ${imgHtml(media, 'document-text-outline')}
          ${featured ? '<span class="wwc-featured-badge">Featured</span>' : ''}
        </div>
        ${flagsHtml(urgent, verified)}
        <p class="wwc-card-title">${title}</p>
        ${priceHtml}
        <div class="wwc-card-loc"><ion-icon name="location-outline" aria-hidden="true"></ion-icon><span>${loc}</span></div>
      </a>`;
  }

  function cardProduct(row) {
    const id = Number(row.id);
    const name = escapeHtml(String(row.name ?? ''));
    const price = String(row.price_amount ?? '');
    const cur = String(row.currency ?? 'USD');
    const loc = escapeHtml(formatListingLoc(row));
    return `
      <a href="product.html?id=${id}" class="wwc-card">
        <div class="wwc-card-img-wrap">${imgHtml(row.image_url, 'cube-outline')}</div>
        <p class="wwc-card-title">${name}</p>
        <p class="wwc-card-price">${cur} ${escapeHtml(price)}</p>
        <div class="wwc-card-loc"><ion-icon name="location-outline" aria-hidden="true"></ion-icon><span>${loc}</span></div>
      </a>`;
  }

  function cardStore(row) {
    const id = Number(row.id);
    const name = escapeHtml(String(row.name ?? ''));
    const loc = escapeHtml(formatListingLoc(row));
    return `
      <a href="store.html?id=${id}" class="wwc-card">
        <div class="wwc-card-img-wrap">${imgHtml(row.logo_url, 'storefront-outline')}</div>
        <p class="wwc-card-title">${name}</p>
        <p class="wwc-card-meta">Store</p>
        <div class="wwc-card-loc"><ion-icon name="location-outline" aria-hidden="true"></ion-icon><span>${loc}</span></div>
      </a>`;
  }

  function cardDirectory(row) {
    const id = Number(row.id);
    const name = escapeHtml(String(row.business_name ?? ''));
    const loc = escapeHtml(formatDirLoc(row));
    return `
      <a href="directory-entry.html?id=${id}" class="wwc-card">
        <div class="wwc-card-img-wrap">${imgHtml(row.logo_url, 'business-outline')}</div>
        <p class="wwc-card-title">${name}</p>
        <p class="wwc-card-meta">Business</p>
        <div class="wwc-card-loc"><ion-icon name="location-outline" aria-hidden="true"></ion-icon><span>${loc}</span></div>
      </a>`;
  }

  function featuredCard(item, showBadge) {
    if (item.kind === 'product' && item.product) {
      const row = item.product;
      const id = Number(row.id);
      const name = escapeHtml(String(row.name ?? ''));
      const price = String(row.price_amount ?? '');
      const cur = String(row.currency ?? 'USD');
      const loc = escapeHtml(formatListingLoc(row));
      const badge = showBadge ? '<span class="wwc-featured-badge">Featured</span>' : '';
      return `
        <a href="product.html?id=${id}" class="wwc-card${showBadge ? ' is-featured' : ''}">
          <div class="wwc-card-img-wrap">${imgHtml(row.image_url, 'cube-outline')}${badge}</div>
          <p class="wwc-card-title">${name}</p>
          <p class="wwc-card-price">${cur} ${escapeHtml(price)}</p>
          <div class="wwc-card-loc"><ion-icon name="location-outline" aria-hidden="true"></ion-icon><span>${loc}</span></div>
        </a>`;
    }
    if (item.listing) {
      const row = item.listing;
      const featured = row.is_featured === true || showBadge;
      const id = Number(row.id);
      const title = escapeHtml(String(row.title ?? ''));
      const media = row.media_url;
      const price = row.price_amount != null ? String(row.price_amount) : null;
      const cur = String(row.currency ?? 'USD');
      const pt = String(row.pricing_type ?? 'fixed');
      const loc = escapeHtml(formatListingLoc(row));
      const urgent = row.is_urgent === true;
      const verified = row.is_verified === true;
      const priceHtml = price
        ? `<p class="wwc-card-price">${cur} ${escapeHtml(price)}${pt === 'hourly' ? '/hr' : ''}</p>`
        : `<p class="wwc-card-meta">See listing</p>`;
      return `
        <a href="listing.html?id=${id}" class="wwc-card${featured ? ' is-featured' : ''}${urgent ? ' is-urgent' : ''}">
          <div class="wwc-card-img-wrap">
            ${imgHtml(media, 'document-text-outline')}
            ${featured ? '<span class="wwc-featured-badge">Featured</span>' : ''}
          </div>
          ${flagsHtml(urgent, verified)}
          <p class="wwc-card-title">${title}</p>
          ${priceHtml}
          <div class="wwc-card-loc"><ion-icon name="location-outline" aria-hidden="true"></ion-icon><span>${loc}</span></div>
        </a>`;
    }
    return '';
  }

  function rail(title, seeHref, cardsHtml) {
    if (!cardsHtml.trim()) return '';
    return `
      <section class="wwc-rail">
        <div class="wwc-rail-head">
          <h2 class="wwc-rail-title">${escapeHtml(title)}</h2>
          <a href="${seeHref}" class="wwc-rail-see">See all &gt;</a>
        </div>
        <div class="wwc-rail-scroll">${cardsHtml}</div>
      </section>`;
  }

  function renderFeed() {
    if (!feed) return;
    const parts = [];
    const cap = (arr) => (Array.isArray(arr) ? arr.slice(0, HOME_RAIL_LIMIT) : []);

    if (feed.featured.length) {
      parts.push(
        rail(
          'Featured',
          'services.html',
          cap(feed.featured).map((f) => featuredCard(f, true)).join('')
        )
      );
    }

    if (feed.directory.length) {
      parts.push(
        rail(
          'Business directory',
          'directory.html',
          cap(feed.directory).map((r) => cardDirectory(r)).join('')
        )
      );
    }

    if (feed.classifieds.length || feed.stores.length) {
      const recRows = [
        ...feed.classifieds.map((r) => ({ kind: 'listing', row: r })),
        ...feed.stores.map((r) => ({ kind: 'store', row: r })),
      ].slice(0, HOME_RAIL_LIMIT);
      const rec = recRows
        .map((item) =>
          item.kind === 'listing' ? cardListing(item.row, 'listing.html') : cardStore(item.row)
        )
        .join('');
      parts.push(rail('Recommended', 'classifieds.html', rec));
    }

    if (feed.services.length) {
      parts.push(
        rail(
          'Professional services',
          'services.html',
          cap(feed.services).map((r) => cardListing(r, 'listing.html')).join('')
        )
      );
    }
    if (feed.products.length) {
      parts.push(
        rail(
          'Products',
          'products.html',
          cap(feed.products).map((r) => cardProduct(r)).join('')
        )
      );
    }
    if (feed.classifieds.length) {
      parts.push(
        rail(
          'Marketplace',
          'classifieds.html',
          cap(feed.classifieds).map((r) => cardListing(r, 'listing.html')).join('')
        )
      );
    }
    if (feed.community.length) {
      parts.push(
        rail(
          'Classifieds',
          'community.html',
          cap(feed.community).map((r) => cardListing(r, 'listing.html')).join('')
        )
      );
    }
    if (feed.stores.length) {
      parts.push(
        rail(
          'Online stores',
          'stores.html',
          cap(feed.stores).map((r) => cardStore(r)).join('')
        )
      );
    }

    els.feed.innerHTML = parts.join('') || '<p class="wwc-footnote">No listings yet. Check back soon.</p>';
  }

  async function loadLocations() {
    try {
      const data = await apiGet('locations.php', true);
      if (Array.isArray(data.countries)) countries = data.countries;
      if (Array.isArray(data.us_states)) usStates = data.us_states;
    } catch {
      /* optional */
    }
  }

  async function loadFeed() {
    if (!els.feed) return;
    els.feed.innerHTML = '<div class="wwc-loading"><div class="wwc-spinner" role="status" aria-label="Loading"></div></div>';
    try {
      const qs = new URLSearchParams({ section: 'all', limit: String(HOME_RAIL_LIMIT) });
      if (country?.code) qs.set('country', country.code);
      if (usState?.name) qs.set('us_state', usState.name);
      const data = await apiGet(`marketplace-home-feed.php?${qs}`, true, false, FEED_FETCH_TIMEOUT_MS);
      feed = normalizeFeed(data.feed);
      renderFeed();
    } catch (e) {
      els.feed.innerHTML = `
        <div>
          <p class="wwc-feed-error">${escapeHtml(e.message || 'Could not load feed')}</p>
          <button type="button" class="wwc-feed-retry" id="feed-retry">Try again</button>
        </div>`;
      document.getElementById('feed-retry')?.addEventListener('click', loadFeed);
    }
  }

  function renderCategories() {
    if (!els.cats) return;
    els.cats.innerHTML = TOP_CATEGORIES.map(
      (c) => `
      <a href="${c.href}" class="wwc-cat-card">
        <div class="wwc-cat-icon" style="background:${c.bg};color:${c.color}">${c.svg}</div>
        <div class="wwc-cat-label">${c.label}</div>
      </a>`
    ).join('');
  }

  function updateLocLabel() {
    if (els.locLabel) els.locLabel.textContent = locationLabel();
  }

  function openModal(el) {
    el.hidden = false;
    document.body.style.overflow = 'hidden';
  }

  function closeModal(el) {
    el.hidden = true;
    document.body.style.overflow = '';
  }

  function renderCountryList(filter) {
    const q = (filter || '').trim().toLowerCase();
    const list = q
      ? countries.filter((c) => c.name.toLowerCase().includes(q) || c.code.toLowerCase().includes(q))
      : countries;
    els.locCountryList.innerHTML = list
      .map(
        (c) =>
          `<button type="button" class="wwc-modal-row" data-code="${escapeAttr(c.code)}">${escapeHtml(c.name)} (${escapeHtml(c.code)})</button>`
      )
      .join('');
    els.locCountryList.querySelectorAll('[data-code]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const code = btn.getAttribute('data-code');
        country = countries.find((c) => c.code === code) || null;
        usState = null;
        updateLocLabel();
        renderStateList();
        if (country?.code !== 'US') {
          closeModal(els.locModal);
          loadFeed();
        }
      });
    });
  }

  function renderStateList() {
    if (country?.code !== 'US') {
      els.locStateSection.hidden = true;
      return;
    }
    els.locStateSection.hidden = false;
    const items = [{ code: '', name: 'All states' }, ...usStates];
    els.locStateList.innerHTML = items
      .map(
        (s, i) =>
          `<button type="button" class="wwc-modal-row" data-idx="${i}">${escapeHtml(s.name)}</button>`
      )
      .join('');
    els.locStateList.querySelectorAll('[data-idx]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const idx = Number(btn.getAttribute('data-idx'));
        const item = idx === 0 ? null : usStates[idx - 1];
        usState = item;
        updateLocLabel();
        closeModal(els.locModal);
        loadFeed();
      });
    });
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function escapeAttr(s) {
    return escapeHtml(s).replace(/'/g, '&#39;');
  }

  function bindEvents() {
    els.locBtn?.addEventListener('click', () => {
      renderCountryList(els.locCountrySearch?.value || '');
      renderStateList();
      openModal(els.locModal);
    });

    els.locCountrySearch?.addEventListener('input', () => renderCountryList(els.locCountrySearch.value));

    els.locModal?.addEventListener('click', (e) => {
      if (e.target === els.locModal) closeModal(els.locModal);
    });
    els.locModal?.querySelector('[data-loc-all]')?.addEventListener('click', () => {
      country = null;
      usState = null;
      updateLocLabel();
      closeModal(els.locModal);
      void loadFeed();
    });
    els.locModal?.querySelector('[data-loc-done]')?.addEventListener('click', () => closeModal(els.locModal));

    els.search?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const q = els.search.value.trim();
        if (q) window.location.href = `services.html?q=${encodeURIComponent(q)}`;
      }
    });
  }

  async function init() {
    if (!els.feed || booted) return;
    booted = true;
    try {
      renderCategories();
      updateLocLabel();
      bindEvents();
      void loadLocations();
      await loadFeed();
    } catch (e) {
      els.feed.innerHTML = `
        <div>
          <p class="wwc-feed-error">${escapeHtml(e.message || 'Could not load home page')}</p>
          <button type="button" class="wwc-feed-retry" id="feed-retry">Try again</button>
        </div>`;
      document.getElementById('feed-retry')?.addEventListener('click', () => {
        booted = false;
        void init();
      });
    }
  }

  window.WWC_HOME = { init };
})();
